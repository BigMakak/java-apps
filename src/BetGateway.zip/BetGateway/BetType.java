package BetGateway;

public enum BetType {
    STANDARD,
    RISKY,
    FULL_HOUSE
}
