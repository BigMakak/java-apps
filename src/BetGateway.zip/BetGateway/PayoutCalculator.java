package BetGateway;

public interface PayoutCalculator {

    double calculate(Bet bet);
}
